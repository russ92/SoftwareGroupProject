Sprint 2: Streaming tweets

Team Hash Flag
Owen Corrigan
Nicholas Hamm
Russell Ward

Instructions;
From command line, locate the swe-project.jar file then run:

java -jar swe-project.jar
