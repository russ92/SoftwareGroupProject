package sweproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SweProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
